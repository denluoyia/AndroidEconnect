package econnect.main;

public class Constant {
	public static final String DEFAULT_PATH = Utils.getPCHomePath() + "/Econnect/";
}
